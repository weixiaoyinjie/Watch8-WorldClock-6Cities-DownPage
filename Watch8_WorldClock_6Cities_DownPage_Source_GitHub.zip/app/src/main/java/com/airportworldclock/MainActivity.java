package com.airportworldclock;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Wear OS, no third-party UI libraries, no periodic background work.
 * All 134 cities, search, favorite cities, reference choice, 12/24h, DST and time sync
 * are carried forward from the source Android application.
 */
public final class MainActivity extends Activity {
    private static final int BG = Color.BLACK;
    private static final int PANEL = Color.rgb(19, 22, 26);
    private static final int LINE = Color.rgb(43, 49, 53);
    private static final int WHITE = Color.rgb(250, 250, 250);
    private static final int MUTED = Color.rgb(170, 180, 184);
    private static final int SOFT = Color.rgb(115, 127, 131);
    private static final int MINT = Color.rgb(105, 221, 201);
    private static final int SELECTED = Color.rgb(22, 53, 48);
    private static final String PREFS = "airport_world_clock_v1";
    private static final String SERVER = "https://gateway.timeapi.world/timezone/Etc/UTC";
    private static final String[] WEEK = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"};
    private static final int HOME = 0, SEARCH = 1, SETTINGS = 2, REFERENCE = 3, DETAIL = 4,
            CITY_LIST = 5, MANAGE = 6;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> pinned = new ArrayList<>();
    private final ArrayList<String> homeSlots = new ArrayList<>();
    private final ArrayList<ClockRow> visibleRows = new ArrayList<>();
    private SharedPreferences preferences;
    private String referenceCode = "EZE";
    private boolean is24Hour = true, showPinned = true, syncing, hasSynced, foreground;
    private long calibratedEpochAtAnchor, calibratedElapsedAnchor;
    private int screen = HOME, detailBackScreen = HOME, searchBackScreen = HOME;
    private int replacementSlot = -1;
    private AirportCity detailCity;
    private String searchKeyword = "", syncStatus = "设备时间 · 正在校时";
    private ScrollView mainScroll;
    private LinearLayout listContainer;
    private TextView referenceText;
    private TextView networkLabel;
    private boolean roundScreen;
    private float gestureStartX, gestureStartY;
    private boolean trackedGesture;

    private static final class ClockRow {
        final AirportCity city;
        final TextView time, date, difference;
        ClockRow(AirportCity c, TextView t, TextView d, TextView f) {
            city = c; time = t; date = d; difference = f;
        }
    }

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!foreground) return;
            updateClocks();
            long remainder = Math.floorMod(nowEpochMillis(), 60000L);
            handler.postDelayed(this, Math.max(1000L, 60000L - remainder + 80L));
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        roundScreen = getResources().getConfiguration().isScreenRound();
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        loadPreferences();
        showScreen(HOME);
        synchronizeTime();
    }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        roundScreen = config.isScreenRound();
        showScreen(screen);
    }

    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override protected void onPause() {
        foreground = false;
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(ticker);
        super.onDestroy();
    }

    /** On the six-clock home page, a downward gesture opens the separate management page.
     *  It never appears when swiping upward; the visible footer is a tap alternative.
     */
    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (screen == HOME) {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    gestureStartX = event.getX();
                    gestureStartY = event.getY();
                    trackedGesture = true;
                    break;
                case MotionEvent.ACTION_UP:
                    if (trackedGesture) {
                        float dx = event.getX() - gestureStartX;
                        float dy = event.getY() - gestureStartY;
                        trackedGesture = false;
                        if (dy > dp(54) && Math.abs(dx) < dy * .8f) {
                            // Clear the child's pending click before switching the Activity content.
                            MotionEvent cancel = MotionEvent.obtain(event.getDownTime(),
                                    event.getEventTime(), MotionEvent.ACTION_CANCEL,
                                    event.getX(), event.getY(), event.getMetaState());
                            super.dispatchTouchEvent(cancel);
                            cancel.recycle();
                            showScreen(MANAGE);
                            return true;
                        }
                    }
                    break;
                case MotionEvent.ACTION_CANCEL:
                    trackedGesture = false;
                    break;
                default: break;
            }
        } else {
            trackedGesture = false;
        }
        return super.dispatchTouchEvent(event);
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        if (screen == DETAIL) showScreen(detailBackScreen);
        else if (screen == SEARCH) { replacementSlot = -1; showScreen(searchBackScreen); }
        else if (screen != HOME) showScreen(HOME);
        else super.onBackPressed();
    }

    private void loadPreferences() {
        for (String value : preferences.getString("pins", AirportData.DEFAULT_PINS).split(",")) {
            String code = value.trim();
            if (AirportData.BY_CODE.containsKey(code) && !pinned.contains(code)) pinned.add(code);
        }
        // Migrate the old favorites automatically: the first six become the home grid.
        String storedSlots = preferences.getString("home_slots", "");
        String source = storedSlots.isEmpty() ? TextUtils.join(",", pinned) : storedSlots;
        for (String value : source.split(",")) {
            String code = value.trim();
            if (AirportData.BY_CODE.containsKey(code) && !homeSlots.contains(code) && homeSlots.size() < 6) {
                homeSlots.add(code);
            }
        }
        for (AirportCity city : AirportData.ALL) {
            if (homeSlots.size() == 6) break;
            if (!homeSlots.contains(city.code)) homeSlots.add(city.code);
        }
        for (String code : homeSlots) if (!pinned.contains(code)) pinned.add(code);
        referenceCode = preferences.getString("reference", "EZE");
        if (!AirportData.BY_CODE.containsKey(referenceCode)) referenceCode = "EZE";
        is24Hour = preferences.getBoolean("24h", true);
    }

    private void savePreferences() {
        preferences.edit()
                .putString("pins", TextUtils.join(",", pinned))
                .putString("home_slots", TextUtils.join(",", homeSlots))
                .putString("reference", referenceCode)
                .putBoolean("24h", is24Hour).apply();
    }

    private void swapHomeSlots(int index, int delta) {
        int other = index + delta;
        if (index < 0 || index >= homeSlots.size() || other < 0 || other >= homeSlots.size()) return;
        String temp = homeSlots.get(index);
        homeSlots.set(index, homeSlots.get(other));
        homeSlots.set(other, temp);
        savePreferences();
        int oldScrollY = mainScroll.getScrollY();
        showScreen(MANAGE);
        mainScroll.post(() -> mainScroll.scrollTo(0, oldScrollY));
    }

    private void selectHomeCity(int slot, String code) {
        if (slot < 0 || slot >= 6 || !AirportData.BY_CODE.containsKey(code)) return;
        // Already present? Swap places instead of accidentally showing duplicates.
        int existing = homeSlots.indexOf(code);
        if (existing >= 0 && existing != slot) {
            String old = homeSlots.get(slot);
            homeSlots.set(slot, code);
            homeSlots.set(existing, old);
        } else {
            homeSlots.set(slot, code);
        }
        if (!pinned.contains(code)) pinned.add(code);
        savePreferences();
        replacementSlot = -1;
        searchKeyword = "";
        showScreen(MANAGE);
    }

    private void openSearch(int back, int slot) {
        searchBackScreen = back;
        replacementSlot = slot;
        searchKeyword = "";
        showScreen(SEARCH);
    }

    private void showScreen(int next) {
        screen = next;
        visibleRows.clear();
        listContainer = null;
        referenceText = null;
        networkLabel = null;

        mainScroll = new ScrollView(this);
        mainScroll.setFillViewport(true);
        mainScroll.setClipToPadding(false);
        mainScroll.setVerticalScrollBarEnabled(false);
        mainScroll.setBackgroundColor(BG);
        mainScroll.setFocusable(true);
        mainScroll.setFocusableInTouchMode(true);
        mainScroll.setOnGenericMotionListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_SCROLL &&
                    (event.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER) ||
                     event.isFromSource(InputDevice.SOURCE_CLASS_POINTER))) {
                float axis = event.getAxisValue(MotionEvent.AXIS_SCROLL);
                if (axis == 0f) axis = event.getAxisValue(MotionEvent.AXIS_VSCROLL);
                mainScroll.scrollBy(0, Math.round(-axis * dp(48)));
                return axis != 0f;
            }
            return false;
        });
        int horizontal = next == HOME ? 0 : dp(roundScreen ? 28 : 14);
        LinearLayout content = column();
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        if (next == HOME) content.setPadding(0, 0, 0, 0);
        else content.setPadding(horizontal, dp(roundScreen ? 27 : 12), horizontal, dp(roundScreen ? 33 : 14));
        mainScroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        setContentView(mainScroll);

        if (next == HOME) buildHome(content);
        else if (next == MANAGE) buildManagement(content);
        else if (next == CITY_LIST) buildCityList(content);
        else if (next == SEARCH) buildSearch(content);
        else if (next == SETTINGS) buildSettings(content);
        else if (next == REFERENCE) buildReference(content);
        else if (next == DETAIL && detailCity != null) buildDetail(content, detailCity);
        updateClocks();
        if (next != SEARCH) mainScroll.requestFocus();
    }

    /** One screen only: three rows by two cities; all settings are on a separate page. */
    private void buildHome(LinearLayout root) {
        LinearLayout viewport = column();
        viewport.setGravity(Gravity.CENTER_HORIZONTAL);
        boolean compact = getResources().getDisplayMetrics().heightPixels /
                getResources().getDisplayMetrics().density < 205f;
        viewport.setPadding(dp(roundScreen ? (compact ? 20 : 23) : 10), dp(compact ? 7 : 11),
                dp(roundScreen ? (compact ? 20 : 23) : 10), dp(compact ? 5 : 10));
        // No settings/management section is attached beneath this home view.
        // The six clocks fit one screen on 40mm and 44mm watches.
        root.addView(viewport, new LinearLayout.LayoutParams(-1,
                getResources().getDisplayMetrics().heightPixels));

        TextView heading = text("世界时间  ·  6 城", 13, MINT, true);
        heading.setGravity(Gravity.CENTER);
        heading.setSingleLine(true);
        viewport.addView(heading, new LinearLayout.LayoutParams(-1, dp(compact ? 19 : 23)));

        LinearLayout grid = column();
        LinearLayout.LayoutParams gridLp = new LinearLayout.LayoutParams(-1, 0, 1f);
        gridLp.topMargin = dp(compact ? 1 : 3);
        viewport.addView(grid, gridLp);
        for (int rowIndex = 0; rowIndex < 3; rowIndex++) {
            LinearLayout pair = row(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams pairLp = new LinearLayout.LayoutParams(-1, 0, 1f);
            if (rowIndex > 0) pairLp.topMargin = dp(compact ? 2 : 4);
            grid.addView(pair, pairLp);
            for (int columnIndex = 0; columnIndex < 2; columnIndex++) {
                int slot = rowIndex * 2 + columnIndex;
                AirportCity city = AirportData.BY_CODE.get(homeSlots.get(slot));
                LinearLayout.LayoutParams cell = new LinearLayout.LayoutParams(0, -1, 1f);
                if (columnIndex == 0) cell.rightMargin = dp(4);
                pair.addView(homeClockCard(city), cell);
            }
        }
        TextView swipe = text("↓  下页管理", compact ? 9 : 10, SOFT, false);
        swipe.setGravity(Gravity.CENTER);
        swipe.setSingleLine(true);
        swipe.setContentDescription("打开第二页管理城市、排序和设置");
        LinearLayout.LayoutParams swipeLp = new LinearLayout.LayoutParams(-1, dp(compact ? 23 : 25));
        swipeLp.topMargin = dp(compact ? 1 : 2);
        viewport.addView(swipe, swipeLp);
        swipe.setOnClickListener(v -> showScreen(MANAGE));
    }

    /** Dedicated lower page, accessible by down-swipe or tapping the footer. */
    private void buildManagement(LinearLayout manage) {
        pageTitle(manage, "下页 · 城市管理", HOME);
        sectionHeader(manage, "首页 6 城 · 更换 / 排序");
        for (int i = 0; i < 6; i++) {
            final int slot = i;
            AirportCity city = AirportData.BY_CODE.get(homeSlots.get(i));
            LinearLayout line = row(Gravity.CENTER_VERTICAL);
            line.setPadding(dp(5), dp(2), dp(5), dp(2));
            line.setBackground(bg(PANEL, LINE, 13));
            manage.addView(line, heightMargin(47, 5));

            TextView label = text((i + 1) + "  " + city.chinese, 12, WHITE, true);
            label.setSingleLine(true);
            label.setAutoSizeTextTypeUniformWithConfiguration(9, 12, 1,
                    TypedValue.COMPLEX_UNIT_SP);
            line.addView(label, new LinearLayout.LayoutParams(0, -1, 1f));
            TextView up = action("↑", 17, dp(39));
            up.setContentDescription("把" + city.chinese + "上移一格");
            line.addView(up, width(dp(31)));
            up.setAlpha(i == 0 ? .35f : 1f);
            up.setOnClickListener(v -> swapHomeSlots(slot, -1));
            TextView down = action("↓", 17, dp(39));
            down.setContentDescription("把" + city.chinese + "下移一格");
            LinearLayout.LayoutParams downLp = width(dp(31));
            downLp.leftMargin = dp(3);
            line.addView(down, downLp);
            down.setAlpha(i == 5 ? .35f : 1f);
            down.setOnClickListener(v -> swapHomeSlots(slot, +1));
            TextView pick = action("换", 12, dp(39));
            pick.setContentDescription("更换第" + (i + 1) + "格的城市");
            LinearLayout.LayoutParams pickLp = width(dp(34));
            pickLp.leftMargin = dp(3);
            line.addView(pick, pickLp);
            pick.setOnClickListener(v -> openSearch(MANAGE, slot));
        }
        TextView search = largeButton("＋ 搜索城市 / 添加收藏", true);
        manage.addView(search, heightMargin(46, 11));
        search.setOnClickListener(v -> openSearch(MANAGE, -1));
        TextView cityList = largeButton("★ 收藏列表 / 全部 134 城市", false);
        manage.addView(cityList, heightMargin(46, 7));
        cityList.setOnClickListener(v -> { showPinned = true; showScreen(CITY_LIST); });
        AirportCity ref = AirportData.BY_CODE.get(referenceCode);
        TextView reference = largeButton("参考城市  " + ref.chinese + "  ·  点击修改", false);
        manage.addView(reference, heightMargin(44, 7));
        reference.setOnClickListener(v -> showScreen(REFERENCE));
        TextView settings = largeButton("⚙ 设置 / 12·24 小时 / 网络校时", false);
        manage.addView(settings, heightMargin(46, 7));
        settings.setOnClickListener(v -> showScreen(SETTINGS));
    }

    private View homeClockCard(AirportCity city) {
        float displayDp = getResources().getDisplayMetrics().heightPixels /
                getResources().getDisplayMetrics().density;
        boolean compact = displayDp < 205f;
        boolean tiny = displayDp < 181f;
        LinearLayout card = column();
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(2), dp(1), dp(2), dp(1));
        boolean selected = city.code.equals(referenceCode);
        card.setBackground(bg(selected ? SELECTED : PANEL, selected ? MINT : LINE, 13));
        TextView name = text(city.chinese, compact ? 10 : 12, selected ? MINT : WHITE, true);
        name.setSingleLine(true);
        name.setGravity(Gravity.CENTER);
        name.setAutoSizeTextTypeUniformWithConfiguration(8, compact ? 10 : 12, 1, TypedValue.COMPLEX_UNIT_SP);
        card.addView(name, new LinearLayout.LayoutParams(-1, 0, .9f));
        TextView clock = text("--:--", compact ? 18 : 22, WHITE, true);
        clock.setGravity(Gravity.CENTER);
        clock.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        clock.setFontFeatureSettings("tnum");
        clock.setSingleLine(true);
        clock.setAutoSizeTextTypeUniformWithConfiguration(14, compact ? 18 : 22, 1,
                TypedValue.COMPLEX_UNIT_SP);
        card.addView(clock, new LinearLayout.LayoutParams(-1, 0, 1.5f));
        TextView date = text("--/--", compact ? 8 : 10, MUTED, false);
        date.setGravity(Gravity.CENTER);
        date.setSingleLine(true);
        date.setAutoSizeTextTypeUniformWithConfiguration(8, compact ? 8 : 10, 1,
                TypedValue.COMPLEX_UNIT_SP);
        if (!tiny) card.addView(date, new LinearLayout.LayoutParams(-1, 0, .85f));
        // The relative-offset detail is intentionally omitted from this compact card.
        TextView difference = text("", 9, SOFT, false);
        visibleRows.add(new ClockRow(city, clock, date, difference));
        card.setContentDescription(city.chinese + "，点击查看详细世界时间");
        card.setOnClickListener(v -> {
            detailCity = city;
            detailBackScreen = HOME;
            showScreen(DETAIL);
        });
        return card;
    }

    private void buildCityList(LinearLayout root) {
        pageTitle(root, "世界城市 · " + AirportData.ALL.size(), MANAGE);
        LinearLayout controls = row(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams cp = width(-1);
        cp.topMargin = dp(8);
        root.addView(controls, cp);
        TextView favorites = action("★ 收藏", 13, dp(45));
        TextView all = action("全部", 13, dp(45));
        TextView search = action("⌕", 24, dp(45));
        favorites.setBackground(bg(showPinned ? SELECTED : PANEL, showPinned ? MINT : LINE, 17));
        all.setBackground(bg(!showPinned ? SELECTED : PANEL, !showPinned ? MINT : LINE, 17));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(45), 1.15f);
        ap.rightMargin = dp(5);
        controls.addView(favorites, ap);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(45), .82f);
        bp.rightMargin = dp(5);
        controls.addView(all, bp);
        controls.addView(search, width(dp(46)));
        search.setContentDescription("搜索机场或城市");
        favorites.setOnClickListener(v -> { showPinned = true; showScreen(CITY_LIST); });
        all.setOnClickListener(v -> { showPinned = false; showScreen(CITY_LIST); });
        search.setOnClickListener(v -> openSearch(CITY_LIST, -1));
        listContainer = column();
        listContainer.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams lp = width(-1);
        lp.topMargin = dp(4);
        root.addView(listContainer, lp);
        renderHomeList();
    }

    private void renderHomeList() {
        if (listContainer == null) return;
        listContainer.removeAllViews();
        visibleRows.clear();
        if (showPinned) {
            ArrayList<AirportCity> favorites = new ArrayList<>();
            for (String code : pinned) {
                AirportCity city = AirportData.BY_CODE.get(code);
                if (city != null) favorites.add(city);
            }
            sectionHeader(listContainer, "收藏 " + favorites.size());
            if (favorites.isEmpty()) emptyHint(listContainer, "暂无收藏\n进入“全部”点击 ☆ 添加城市");
            addCities(listContainer, favorites);
        } else {
            for (String region : AirportData.REGIONS) {
                ArrayList<AirportCity> cities = new ArrayList<>();
                for (AirportCity city : AirportData.ALL) {
                    if (region.equals(city.region)) cities.add(city);
                }
                sectionHeader(listContainer, region + " · " + cities.size());
                addCities(listContainer, cities);
            }
        }
    }

    private void buildSearch(LinearLayout root) {
        pageTitle(root, replacementSlot >= 0 ? "更换第 " + (replacementSlot + 1) + " 格" : "搜索机场", searchBackScreen);
        TextView description = text(replacementSlot >= 0 ? "点城市直接替换 · 可选已收藏城市" : "机场代码 / 中文 / English", 12, MUTED, false);
        description.setGravity(Gravity.CENTER);
        marginTop(root, description, 5, -1, -2);
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(17);
        input.setTextColor(WHITE);
        input.setHintTextColor(SOFT);
        input.setBackground(bg(PANEL, LINE, 15));
        input.setPadding(dp(13), 0, dp(13), 0);
        input.setHint("例如 JFK / 东京");
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        LinearLayout.LayoutParams ep = width(-1);
        ep.height = dp(49);
        ep.topMargin = dp(12);
        root.addView(input, ep);
        listContainer = column();
        LinearLayout.LayoutParams lp = width(-1);
        lp.topMargin = dp(7);
        root.addView(listContainer, lp);
        input.setText(searchKeyword);
        input.setSelection(input.length());
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchKeyword = s.toString();
                renderSearchList();
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(input.getWindowToken(), 0);
                input.clearFocus();
                mainScroll.requestFocus();
                return true;
            }
            return false;
        });
        renderSearchList();
    }

    private void renderSearchList() {
        if (screen != SEARCH || listContainer == null) return;
        listContainer.removeAllViews();
        visibleRows.clear();
        String keyword = searchKeyword.trim();
        if (keyword.isEmpty()) {
            if (replacementSlot >= 0) {
                sectionHeader(listContainer, "直接从收藏中选择");
                ArrayList<AirportCity> favorites = new ArrayList<>();
                for (String code : pinned) {
                    AirportCity city = AirportData.BY_CODE.get(code);
                    if (city != null) favorites.add(city);
                }
                addCities(listContainer, favorites);
                sectionHeader(listContainer, "还可在上方搜索全部 134 城市");
                updateClocks();
            } else {
                emptyHint(listContainer, "输入城市或机场三字代码\n搜索全部 " + AirportData.ALL.size() + " 座城市");
            }
            return;
        }
        ArrayList<AirportCity> matched = new ArrayList<>();
        for (AirportCity city : AirportData.ALL) if (city.matches(keyword)) matched.add(city);
        sectionHeader(listContainer, "找到 " + matched.size() + " 个城市");
        if (matched.isEmpty()) emptyHint(listContainer, "未找到匹配的城市");
        addCities(listContainer, matched);
        updateClocks();
    }

    private void buildSettings(LinearLayout root) {
        pageTitle(root, "设置", MANAGE);
        sectionHeader(root, "时间格式");
        TextView format = largeButton("显示格式：" + (is24Hour ? "24 小时" : "12 小时"), true);
        root.addView(format, heightMargin(48, 7));
        format.setOnClickListener(v -> {
            is24Hour = !is24Hour;
            savePreferences();
            showScreen(SETTINGS);
        });
        sectionHeader(root, "校准");
        TextView sync = largeButton(syncing ? "正在联网校时..." : "↻  手动网络校时", false);
        root.addView(sync, heightMargin(48, 7));
        sync.setOnClickListener(v -> { if (!syncing) synchronizeTime(); });
        networkLabel = text(syncStatus, 12, MUTED, false);
        networkLabel.setGravity(Gravity.CENTER);
        marginTop(root, networkLabel, 10, -1, -2);
        sectionHeader(root, "参考城市");
        AirportCity ref = AirportData.BY_CODE.get(referenceCode);
        TextView pickRef = largeButton(ref.chinese + "  " + ref.code, false);
        root.addView(pickRef, heightMargin(48, 7));
        pickRef.setOnClickListener(v -> showScreen(REFERENCE));
        TextView foot = text("离线可用 · 自动处理夏令时\n仅打开时请求一次校时\n离开应用后停止刷新", 11, SOFT, false);
        foot.setGravity(Gravity.CENTER);
        foot.setLineSpacing(dp(4), 1.0f);
        marginTop(root, foot, 18, -1, -2);
    }

    private void buildReference(LinearLayout root) {
        pageTitle(root, "选择参考城市", MANAGE);
        TextView hint = text("从收藏城市中选择", 12, MUTED, false);
        hint.setGravity(Gravity.CENTER);
        marginTop(root, hint, 4, -1, -2);
        if (pinned.isEmpty()) emptyHint(root, "没有收藏城市\n请返回首页到“全部”添加");
        for (String code : pinned) {
            AirportCity city = AirportData.BY_CODE.get(code);
            if (city == null) continue;
            TextView pick = largeButton((code.equals(referenceCode) ? "✓  " : "") +
                    city.chinese + " · " + city.code, code.equals(referenceCode));
            root.addView(pick, heightMargin(48, 8));
            pick.setOnClickListener(v -> {
                referenceCode = city.code;
                savePreferences();
                showScreen(MANAGE);
            });
        }
    }

    private void buildDetail(LinearLayout root, AirportCity city) {
        pageTitle(root, city.chinese + " · " + city.code, detailBackScreen);
        TextView english = text(city.english + " · " + city.country, 12, MUTED, false);
        english.setGravity(Gravity.CENTER);
        marginTop(root, english, 4, -1, -2);
        Instant instant = Instant.ofEpochMilli(nowEpochMillis());
        ZonedDateTime local = instant.atZone(ZoneId.of(city.zoneId));
        AirportCity reference = AirportData.BY_CODE.get(referenceCode);
        ZonedDateTime refTime = instant.atZone(ZoneId.of(reference.zoneId));
        TextView clock = text(String.format(Locale.US, "%02d:%02d:%02d", local.getHour(),
                local.getMinute(), local.getSecond()), 34, WHITE, true);
        clock.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        clock.setGravity(Gravity.CENTER);
        clock.setAutoSizeTextTypeUniformWithConfiguration(22, 34, 1, TypedValue.COMPLEX_UNIT_SP);
        marginTop(root, clock, 12, -1, dp(49));
        infoLine(root, String.format(Locale.ROOT, "%04d/%02d/%02d  %s",
                local.getYear(), local.getMonthValue(), local.getDayOfMonth(),
                WEEK[local.getDayOfWeek().getValue() - 1]), MINT);
        infoLine(root, "机场：" + city.airports, WHITE);
        infoLine(root, "时区：" + city.zoneId, MUTED);
        infoLine(root, formatUTC(local.getOffset().getTotalSeconds()), MINT);
        infoLine(root, "相对参考：" + relativeOffset(local.getOffset().getTotalSeconds() -
                refTime.getOffset().getTotalSeconds()), WHITE);
        infoLine(root, "夏令时：" + (local.getZone().getRules().isDaylightSavings(instant) ? "正在实行" : "未实行"), MUTED);
        TextView setReference = largeButton("设为参考城市", false);
        root.addView(setReference, heightMargin(48, 11));
        setReference.setOnClickListener(v -> {
            referenceCode = city.code;
            savePreferences();
            showScreen(HOME);
        });
        TextView favorite = largeButton(pinned.contains(city.code) ? "★  取消收藏" : "☆  加入收藏", true);
        root.addView(favorite, heightMargin(48, 7));
        favorite.setOnClickListener(v -> {
            toggleFavorite(city.code);
            showScreen(DETAIL);
        });
    }

    private void infoLine(LinearLayout root, String value, int color) {
        TextView t = text(value, 13, color, false);
        t.setGravity(Gravity.CENTER);
        marginTop(root, t, 9, -1, -2);
    }

    private void sectionHeader(LinearLayout root, String title) {
        TextView heading = text(title, 12, MINT, true);
        heading.setGravity(Gravity.CENTER);
        marginTop(root, heading, 13, -1, dp(21));
    }

    private void emptyHint(LinearLayout root, String msg) {
        TextView text = text(msg, 13, MUTED, false);
        text.setGravity(Gravity.CENTER);
        text.setLineSpacing(dp(6), 1);
        marginTop(root, text, 25, -1, dp(100));
    }

    private void addCities(LinearLayout parent, List<AirportCity> cities) {
        for (AirportCity city : cities) parent.addView(cityRow(city), heightMargin(-2, 6));
    }

    private View cityRow(AirportCity city) {
        LinearLayout card = column();
        card.setPadding(dp(12), dp(9), dp(12), dp(10));
        boolean selected = city.code.equals(referenceCode);
        card.setBackground(bg(selected ? SELECTED : PANEL, selected ? MINT : LINE, 18));
        LinearLayout head = row(Gravity.CENTER_VERTICAL);
        card.addView(head, width(-1));
        LinearLayout nameColumn = column();
        head.addView(nameColumn, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView name = text(city.chinese, 16, WHITE, true);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        nameColumn.addView(name, width(-1));
        TextView nameEn = text(city.code + "  ·  " + city.english, 11, MUTED, false);
        nameEn.setSingleLine(true);
        nameEn.setEllipsize(TextUtils.TruncateAt.END);
        marginTop(nameColumn, nameEn, 2, -1, -2);
        boolean picking = screen == SEARCH && replacementSlot >= 0;
        TextView star = text(picking ? "换" : pinned.contains(city.code) ? "★" : "☆", picking ? 16 : 22,
                pinned.contains(city.code) ? MINT : SOFT, false);
        star.setGravity(Gravity.CENTER);
        star.setContentDescription(picking ? "选择 " + city.chinese :
                (pinned.contains(city.code) ? "取消收藏 " : "收藏 ") + city.chinese);
        head.addView(star, width(dp(45)));
        star.getLayoutParams().height = dp(44);
        star.setOnClickListener(v -> {
            if (screen == SEARCH && replacementSlot >= 0) {
                selectHomeCity(replacementSlot, city.code);
                return;
            }
            int y = mainScroll.getScrollY();
            toggleFavorite(city.code);
            if (screen == CITY_LIST) showScreen(CITY_LIST);
            else if (screen == SEARCH) showScreen(SEARCH);
            mainScroll.post(() -> mainScroll.scrollTo(0, y));
        });

        TextView time = text("--:--", 33, WHITE, true);
        time.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        time.setFontFeatureSettings("tnum");
        time.setGravity(Gravity.CENTER);
        time.setSingleLine(true);
        time.setAutoSizeTextTypeUniformWithConfiguration(22, 35, 1, TypedValue.COMPLEX_UNIT_SP);
        marginTop(card, time, 1, -1, dp(39));
        TextView date = text("--/--", 11, MUTED, false);
        date.setGravity(Gravity.CENTER);
        marginTop(card, date, 1, -1, -2);
        TextView difference = text("", 11, MUTED, false);
        difference.setGravity(Gravity.CENTER);
        difference.setSingleLine(true);
        difference.setAutoSizeTextTypeUniformWithConfiguration(9, 11, 1, TypedValue.COMPLEX_UNIT_SP);
        marginTop(card, difference, 4, -1, -2);
        card.setContentDescription(city.chinese + " 世界时间，点击查看详情；长按设为参考城市");
        card.setOnClickListener(v -> {
            if (screen == SEARCH && replacementSlot >= 0) {
                selectHomeCity(replacementSlot, city.code);
                return;
            }
            detailCity = city;
            detailBackScreen = screen;
            showScreen(DETAIL);
        });
        card.setOnLongClickListener(v -> {
            if (screen == SEARCH && replacementSlot >= 0) {
                selectHomeCity(replacementSlot, city.code);
                return true;
            }
            referenceCode = city.code;
            savePreferences();
            showScreen(HOME);
            return true;
        });
        visibleRows.add(new ClockRow(city, time, date, difference));
        return card;
    }

    private void toggleFavorite(String code) {
        if (pinned.contains(code)) {
            if (homeSlots.contains(code)) {
                Toast.makeText(this, "请先在管理页更换这个城市", Toast.LENGTH_SHORT).show();
                return;
            }
            pinned.remove(code);
        } else pinned.add(code);
        savePreferences();
    }

    private void updateClocks() {
        AirportCity refCity = AirportData.BY_CODE.get(referenceCode);
        if (refCity == null) return;
        Instant instant = Instant.ofEpochMilli(nowEpochMillis());
        ZonedDateTime base = instant.atZone(ZoneId.of(refCity.zoneId));
        if (referenceText != null) {
            referenceText.setText(refCity.chinese + "  " + formatTime(base));
        }
        int referenceOffset = base.getOffset().getTotalSeconds();
        for (ClockRow item : visibleRows) {
            ZonedDateTime local = instant.atZone(ZoneId.of(item.city.zoneId));
            item.time.setText(formatTime(local));
            String date = String.format(Locale.US, "%02d/%02d", local.getMonthValue(), local.getDayOfMonth())
                    + " " + WEEK[local.getDayOfWeek().getValue() - 1];
            long dayDiff = ChronoUnit.DAYS.between(base.toLocalDate(), local.toLocalDate());
            // The tiny home grid only shows a compact date; other views keep full info.
            if (item.difference.getParent() != null) {
                if (dayDiff == 1) date += " · 明天";
                else if (dayDiff == -1) date += " · 昨天";
                else if (dayDiff > 1) date += " · +" + dayDiff + "天";
                else if (dayDiff < -1) date += " · " + dayDiff + "天";
            }
            item.date.setText(date);
            String dayNight = local.getHour() >= 7 && local.getHour() < 19 ? "白天" : "夜间";
            item.difference.setText(formatUTC(local.getOffset().getTotalSeconds())
                    + "  ·  " + relativeOffset(local.getOffset().getTotalSeconds() - referenceOffset)
                    + "  ·  " + dayNight);
        }
    }

    private String formatTime(ZonedDateTime dt) {
        if (is24Hour) return String.format(Locale.US, "%02d:%02d", dt.getHour(), dt.getMinute());
        return String.format(Locale.US, "%02d:%02d %s", (dt.getHour() + 11) % 12 + 1,
                dt.getMinute(), dt.getHour() >= 12 ? "PM" : "AM");
    }

    private static String formatUTC(int seconds) {
        int minutes = Math.abs(seconds) / 60;
        return String.format(Locale.US, "UTC%s%02d:%02d",
                seconds < 0 ? "−" : "+", minutes / 60, minutes % 60);
    }

    private static String relativeOffset(int seconds) {
        if (seconds == 0) return "同参考";
        int minutes = Math.abs(seconds) / 60;
        String value = (minutes / 60 > 0 ? (minutes / 60) + "时" : "")
                + (minutes % 60 > 0 ? (minutes % 60) + "分" : "");
        return (seconds > 0 ? "快" : "慢") + value;
    }

    private long nowEpochMillis() {
        return hasSynced ? calibratedEpochAtAnchor + SystemClock.elapsedRealtime() - calibratedElapsedAnchor
                : System.currentTimeMillis();
    }

    private void synchronizeTime() {
        if (syncing) return;
        syncing = true;
        syncStatus = "正在连接网络时间 API…";
        updateSyncLabel();
        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                long start = SystemClock.elapsedRealtime();
                conn = (HttpURLConnection) new URL(SERVER).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("User-Agent", "AirportWorldClock-Wear/1.0");
                if (conn.getResponseCode() != 200) throw new IllegalStateException("HTTP " + conn.getResponseCode());
                String body;
                try (InputStream input = conn.getInputStream();
                     ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                    byte[] block = new byte[1024];
                    int length;
                    while ((length = input.read(block)) != -1) {
                        buffer.write(block, 0, length);
                        if (buffer.size() > 32768) throw new IllegalStateException("Response too large");
                    }
                    body = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
                }
                JSONObject result = new JSONObject(body);
                String iso = result.optString("utc_datetime", "");
                if (iso.isEmpty()) iso = result.optString("datetime", "");
                long epoch = !iso.isEmpty() ? OffsetDateTime.parse(iso).toInstant().toEpochMilli()
                        : result.getLong("unixtime") * 1000L;
                long end = SystemClock.elapsedRealtime();
                long calibrated = epoch + (end - start) / 2;
                double difference = (calibrated - System.currentTimeMillis()) / 1000.0;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    calibratedEpochAtAnchor = calibrated;
                    calibratedElapsedAnchor = end;
                    hasSynced = true;
                    syncing = false;
                    syncStatus = String.format(Locale.ROOT, "网络已校时 · 偏差 %+.1f 秒", difference);
                    updateSyncLabel();
                    handler.removeCallbacks(ticker);
                    if (foreground) handler.post(ticker);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    syncing = false;
                    syncStatus = hasSynced ? "沿用已同步时间 · 可重试" : "校时失败 · 使用设备时间";
                    updateSyncLabel();
                    updateClocks();
                });
            } finally {
                if (conn != null) conn.disconnect();
            }
        }, "watch-worldclock-sync").start();
    }

    private void updateSyncLabel() {
        if (screen == SETTINGS) showScreen(SETTINGS);
        else if (networkLabel != null) networkLabel.setText(syncStatus);
    }

    private void pageTitle(LinearLayout root, String title, int backTo) {
        LinearLayout heading = row(Gravity.CENTER_VERTICAL);
        root.addView(heading, width(-1));
        TextView back = action("‹", 28, dp(43));
        back.setContentDescription("返回");
        heading.addView(back, width(dp(43)));
        back.setOnClickListener(v -> {
            if (screen == SEARCH) replacementSlot = -1;
            showScreen(backTo);
        });
        TextView label = text(title, 17, WHITE, true);
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        label.setAutoSizeTextTypeUniformWithConfiguration(12, 17, 1, TypedValue.COMPLEX_UNIT_SP);
        heading.addView(label, new LinearLayout.LayoutParams(0, dp(43), 1f));
        TextView spacer = text("", 12, WHITE, false);
        heading.addView(spacer, width(dp(43)));
    }

    private TextView largeButton(String value, boolean highlight) {
        TextView button = text(value, 14, highlight ? MINT : WHITE, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(5), dp(4), dp(5), dp(4));
        button.setBackground(bg(highlight ? SELECTED : PANEL, LINE, 16));
        return button;
    }

    private TextView action(String value, float sp, int height) {
        TextView label = text(value, sp, WHITE, true);
        label.setGravity(Gravity.CENTER);
        label.setMinimumHeight(height);
        label.setBackground(bg(PANEL, LINE, 15));
        return label;
    }

    private TextView text(String value, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable bg(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row(int gravity) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(gravity);
        return l;
    }

    private LinearLayout.LayoutParams width(int value) {
        return new LinearLayout.LayoutParams(value, -2);
    }

    private LinearLayout.LayoutParams heightMargin(int height, int top) {
        LinearLayout.LayoutParams l = width(-1);
        l.height = height < 0 ? height : dp(height);
        l.topMargin = dp(top);
        return l;
    }

    private void marginTop(LinearLayout parent, View v, int top, int width, int height) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width, height);
        lp.topMargin = dp(top);
        parent.addView(v, lp);
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + .5f);
    }
}
